#!/bin/sh
sudo python3 epitech_api_flask.py
